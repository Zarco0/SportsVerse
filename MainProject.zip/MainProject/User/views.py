from django.shortcuts import render,redirect
from User.models import *
from Guest.models import tbl_newUser
from Organization.models import tbl_Tournament

# Create your views here.
def HomePageInsert(request):
    if request.method=="POST":
        return redirect("webuser:homeInsert")
    else:
        return render(request,"User/HomePage.html")
    
def ChangePassInsert(request):
    if request.method=="POST":
        usercount=tbl_newUser.objects.filter(id=request.session["uid"],password=request.POST.get('Cpass')).count()
        if usercount>0:
            user=tbl_newUser.objects.get(id=request.session["uid"],password=request.POST.get('Cpass'))
            if request.POST.get('Npass')==request.POST.get('ConPass'):
                user.password=request.POST.get('Npass')
                user.save()
                return redirect("webuser:homeInsert")
            else:
                return render(request,"User/ChangePassword.html")
        else:
            return render(request,"User/ChangePassword.html")
    
    else:
        return render(request,"User/ChangePassword.html")
    
def EditProfileInsert(request):
    data=tbl_newUser.objects.get(id=request.session["uid"])
    if request.method=="POST":
        data.name=request.POST.get('txtname')
        data.contact=request.POST.get('txtcon')
        data.address=request.POST.get('addr')
        data.save()
        return redirect("webuser:MyPInsert")
    else:
        return render(request,"User/EditProfile.html",{'data':data})
    
def MyProfileInsert(request):
    data=tbl_newUser.objects.get(id=request.session["uid"])
    return render(request,"User/MyProfile.html",{'data':data})

def ViewTourInsert(request):
    tourdata=tbl_Tournament.objects.all()
    if request.method=="POST":
        return redirect("webuser:viewTour")
    else:
        return render(request,"User/ViewsTournament.html",{'TOUVIE':tourdata})
