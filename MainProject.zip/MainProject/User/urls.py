from django.urls import path
app_name="webuser"
from User import views

urlpatterns = [

    path('HomePage/',views.HomePageInsert,name="homeInsert"),
    path('ChangePassword/',views.ChangePassInsert,name="changePInsert"),
    path('EditProfile/',views.EditProfileInsert,name="editPInsert"),
    path('MyProfile/',views.MyProfileInsert,name="MyPInsert"),
    path('ViewTournament/',views.ViewTourInsert,name="viewTour")
]