from django.urls import path
app_name="weborg"
from Organization import views

urlpatterns = [

    path('HomePage/',views.HomePageInsert,name="homeInsert"),
    path('ChangePassword/',views.ChangePassInsert,name="changePInsert"),
    path('EditProfile/',views.EditProfileInsert,name="editPInsert"),
    path('MyProfile/',views.MyProfileInsert,name="MyPInsert"),
    path('Tournaments/',views.TournamentsInsert,name="tourInsert"),
    path('Tournamentsdelete/<int:tid>',views.TournamentsDelete,name="tourdelete"),

]