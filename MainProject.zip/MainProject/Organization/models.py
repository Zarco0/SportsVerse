from django.db import models
from Admin.models import *
from Guest.models import *

# Create your models here.
class tbl_Tournament(models.Model):
    tournamenttype=models.ForeignKey(tbl_TourType,on_delete=models.CASCADE)
    game=models.ForeignKey(tbl_Game,on_delete=models.CASCADE)
    name=models.CharField(max_length=50)
    teamcount=models.CharField(max_length=50)
    details=models.CharField(max_length=50)
    regFuser=models.CharField(max_length=50)
    regFteam=models.CharField(max_length=50)
    oraganization=models.ForeignKey(tbl_organization,on_delete=models.CASCADE)