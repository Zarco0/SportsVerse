from django.shortcuts import render,redirect
from Organization.models import *
from Guest.models import tbl_organization

# Create your views here.
def HomePageInsert(request):
    if request.method=="POST":
        return redirect("weborg:homeInsert")
    else:
        return render(request,"Organization/HomePage.html")
    
def ChangePassInsert(request):
    if request.method=="POST":
        clubcount=tbl_organization.objects.filter(id=request.session["oid"],password=request.POST.get('Cpass')).count()
        if clubcount>0:
            club=tbl_organization.objects.get(id=request.session["oid"],password=request.POST.get('Cpass'))
            if request.POST.get('Npass')==request.POST.get('ConPass'):
                club.password=request.POST.get('Npass')
                club.save()
                return redirect("weborg:homeInsert")
            else:
                return render(request,"Organization/ChangePassword.html")
        else:
            return render(request,"Organization/ChangePassword.html")
    else:
        return render(request,"Organization/ChangePassword.html")
    
def EditProfileInsert(request):
    data=tbl_organization.objects.get(id=request.session["oid"])
    if request.method=="POST":
        data.name=request.POST.get('txtname')
        data.contact=request.POST.get('txtcon')
        data.email=request.POST.get('txtemail')
        data.save()
        return redirect("weborg:MyPInsert")
    else:
        return render(request,"Organization/EditProfile.html",{'data':data})
    
def MyProfileInsert(request):
    data=tbl_organization.objects.get(id=request.session["oid"])
    return render(request,"Organization/MyProfile.html",{'data':data})

def TournamentsInsert(request):
    
    org=tbl_organization.objects.get(id=request.session["oid"])
    tourdata=tbl_Tournament.objects.filter(oraganization=org)
    tour=tbl_TourType.objects.all()
    gam=tbl_Game.objects.all()
    if request.method=="POST":

        tourid=request.POST.get('sel_tourtype')
        tourt=tbl_TourType.objects.get(id=tourid)

        gamid=request.POST.get('sel_game')
        game=tbl_Game.objects.get(id=gamid)

        tbl_Tournament.objects.create(tournamenttype=tourt,game=game,name=request.POST.get('txtTname'),teamcount=request.POST.get('txtTCount'),details=request.POST.get('Tdetails'),regFuser=request.POST.get('txtUfee'),regFteam=request.POST.get('txtTfee'),oraganization=org)
        return redirect("weborg:tourInsert")
    else:
        return render(request,"Organization/Tournament.html",{'TOR':tour,'GAM':gam,'viewtour':tourdata})
    
def TournamentsDelete(request,tid):
    tbl_Tournament.objects.get(id=tid).delete()
    return redirect("weborg:tourInsert")
