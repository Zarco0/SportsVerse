from django.urls import path
app_name="webadmin"
from Admin import views


urlpatterns = [

    path('District/', views.districtInsert,name="districtInsert"),
    path('deletedistrict/<int:did>', views.Districtdelete,name="deletedistrict"),
    path('editdistrict/<int:did>', views.Districtedit,name="editdistrict"),

    
    path('Category/', views.categoryInsert,name="categoryInsert"),
    path('deletecategory/<int:cid>',views.Category_delete,name="deletecategory"),
    path('editdicategory/<int:cid>', views.Categoryedit,name="editcategory"),
    


    path('Brand/', views.brandInsert,name="brandInsert"),
    path('deletebrand/<int:bid>',views.Brand_delete,name="deletebrand"),
    path('editbrand/<int:bid>', views.Brandedit,name="editbrand"),


    path('Place/', views.placeInsert,name="placeInsert"),
    path('deleteplace/<int:pid>',views.Placedelete,name="deleteplace"),
    path('editplace/<int:pid>',views.Placeedit,name="editplace"),

    path('Subcategory/', views.subcategoryInsert,name="subcategoryInsert"),

    path('Sports/',views.SportsInsert,name="SportsInsert"),
    path('deletesports/<int:sid>', views.Sports_delete,name="deletesports"),
    path('editsports/<int:sid>', views.Sportsedit,name="editsports"),

    path('Tournament/',views.TourTypeinsert,name="tourtypeInsert"),
    path('Tournamentdelete/<int:tid>',views.TouetypeDelete,name="tourtypeDelete"),
    path('Tournamentedit/<int:tid>',views.TourtypeEdit,name="tourtypeEdit"),

    path('Game/',views.Gameinsert,name="gameInsert"),
    path('DeleteGame/<int:gid>',views.GameDelete,name="gameDelete"),
    path('EditGame/<int:gid>',views.GameEdit,name="gameEdit"),

    
    

 
]