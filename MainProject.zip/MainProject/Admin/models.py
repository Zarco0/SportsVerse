from django.db import models

# Create your models here.

class tbl_District(models.Model):
    name=models.CharField(max_length=50)

class tbl_Category(models.Model):
    name=models.CharField(max_length=50)

class tbl_Brand(models.Model):
    name=models.CharField(max_length=50)

class tbl_Place(models.Model):
    place_name=models.CharField(max_length=50)
    place_pincode=models.IntegerField(max_length=50)
    district=models.ForeignKey(tbl_District,on_delete=models.SET_NULL,null=True)

class tbl_subcategory(models.Model):
    category=models.ForeignKey(tbl_Category,on_delete=models.CASCADE)
    subcategory=models.CharField(max_length=50,null=True)

#------------------Project-----------------

class tbl_Sports(models.Model):
    sports_name=models.CharField(max_length=50)

class tbl_TourType(models.Model):
    name=models.CharField(max_length=50)

class tbl_Game(models.Model):
    name=models.CharField(max_length=50)
