from django.shortcuts import render,redirect

from Admin.models import *

# Create your views here.

#--------------------------Inserting values-----------------------------------

def districtInsert(request):
    districtdata=tbl_District.objects.all()
    if request.method=="POST":
        tbl_District.objects.create(name=request.POST.get('txtdistrict'))
        return render(request,"Admin/District.html",{'viewdis':districtdata})
    else:
        return render(request,"Admin/District.html",{'viewdis':districtdata})
    

def categoryInsert(request):
    discategory=tbl_Category.objects.all()
    if request.method=="POST":
        tbl_Category.objects.create(name=request.POST.get('txtcat'))
        return render(request,"Admin/Category.html",{'viewcat':discategory})
    else:
        return render(request,"Admin/Category.html",{'viewcat':discategory})
    
    
def brandInsert(request):
    disbrand=tbl_Brand.objects.all()
    if request.method=="POST":
        tbl_Brand.objects.create(name=request.POST.get('txtbrand'))
        return render(request,"Admin/Brand.html",{'viewbrand':disbrand})
    else:
        return render(request,"Admin/Brand.html",{'viewbrand':disbrand})
    

    
def placeInsert(request):
    dis=tbl_District.objects.all()
    pl=tbl_Place.objects.all()
    if request.method=="POST":

        disid=request.POST.get('sel_district')
        dist=tbl_District.objects.get(id=disid)

        tbl_Place.objects.create(place_name=request.POST.get('txtplace'),place_pincode=request.POST.get('txtpin'),district=dist)
        return redirect("webadmin:placeInsert")
    else:
        return render(request,"Admin/Place.html",{'DIS':dis,'PLA':pl})
    

def subcategoryInsert(request):
    sub=tbl_Category.objects.all()
    if request.method=="POST":

        subid=request.POST.get('sel_subdistrict')
        subc=tbl_Category.objects.get(id=subid)

        tbl_subcategory.objects.create(subcategory=request.POST.get('txtsub'),category=subc)
        return render(request,"Admin/Subcategory.html")
    else:
        return render(request,"Admin/Subcategory.html",{'SUB':sub})
    
def TourTypeinsert(request):
    tourtypedata=tbl_TourType.objects.all()
    if request.method=="POST":
        tbl_TourType.objects.create(name=request.POST.get('txtTType'))
        return render(request,"Admin/TournamentType.html",{'viewTT':tourtypedata})
    else:
        return render(request,"Admin/TournamentType.html",{'viewTT':tourtypedata})
    
def Gameinsert(request):
    gamedata=tbl_Game.objects.all()
    if request.method=="POST":
        tbl_Game.objects.create(name=request.POST.get('txtgame'))
        return render(request,"Admin/Games.html",{'viewG':gamedata})
    else:
        return render(request,"Admin/Games.html",{'viewG':gamedata})

#-------------------------Deleting values---------------------------
    
def Districtdelete(request,did):
    tbl_District.objects.get(id=did).delete()
    return redirect("webadmin:districtInsert")

def Brand_delete(request,bid):
    tbl_Brand.objects.get(id=bid).delete()
    return redirect("webadmin:brandInsert")

def Category_delete(request,cid):
    tbl_Category.objects.get(id=cid).delete()
    return redirect("webadmin:categoryInsert")

def Placedelete(request,pid):
    tbl_Place.objects.get(id=pid).delete()
    return redirect("webadmin:placeInsert")

def TouetypeDelete(request,tid):
    tbl_TourType.objects.get(id=tid).delete()
    return redirect("webadmin:tourtypeInsert")

def GameDelete(request,gid):
    tbl_Game.objects.get(id=gid).delete()
    return redirect("webadmin:gameInsert")

# -------------------Editing values-------------------------------

def Districtedit(request,did):
    dis=tbl_District.objects.get(id=did)
    if request.method=="POST":
        dis.name=request.POST.get('txtdistrict')
        dis.save()
        return redirect("webadmin:districtInsert")
    else:
        return render(request,"Admin/District.html",{'editdis':dis})

def Brandedit(request,bid):
    dis=tbl_Brand.objects.get(id=bid)
    if request.method=="POST":
        dis.name=request.POST.get('txtbrand')
        dis.save()
        return redirect("webadmin:brandInsert")
    else:
        return render(request,"Admin/Brand.html",{'editbrand':dis})

def Categoryedit(request,cid):
    dis=tbl_Category.objects.get(id=cid)
    if request.method=="POST":
        dis.name=request.POST.get('txtcat')
        dis.save()
        return redirect("webadmin:categoryInsert")
    else:
        return render(request,"Admin/Category.html",{'editcat':dis})
    
def Placeedit(request,pid):
    pla=tbl_Place.objects.get(id=pid)
    if request.method=="POST":
        pla.place_name=request.POST.get('txtplace')
        pla.place_pincode=request.POST.get('txtpin')
        pla.save()
        return redirect("webadmin:placeInsert")
    else:
        return render(request,"Admin/Place.html",{'editplace':pla})
    
def TourtypeEdit(request,tid):
    tot=tbl_TourType.objects.get(id=tid)
    if request.method=="POST":
        tot.name=request.POST.get('txtTType')
        tot.save()
        return redirect("webadmin:tourtypeInsert")
    else:
        return render(request,"Admin/TournamentType.html",{'edittot':tot})
    
def GameEdit(request,gid):
    gam=tbl_Game.objects.get(id=gid)
    if request.method=="POST":
        gam.name=request.POST.get('txtgame')
        gam.save()
        return redirect("webadmin:gameInsert")
    else:
        return render(request,"Admin/Games.html",{'editgame':gam})

#---------------------Project---------------------

def SportsInsert(request):
    sportsdata=tbl_Sports.objects.all()
    if request.method=="POST":
        tbl_Sports.objects.create(sports_name=request.POST.get('txtsname'))
        return render(request,"Admin/Sports.html",{'viewsports':sportsdata})
    else:
        return render(request,"Admin/Sports.html",{'viewsports':sportsdata})
    
def Sports_delete(request,sid):
    tbl_Sports.objects.get(id=sid).delete()
    return redirect("webadmin:SportsInsert")

def Sportsedit(request,sid):
    spo=tbl_Sports.objects.get(id=sid)
    if request.method=="POST":
        spo.sports_name=request.POST.get('txtsname')
        spo.save()
        return redirect("webadmin:SportsInsert")
    else:
        return render(request,"Admin/Sports.html",{'editpos':spo})