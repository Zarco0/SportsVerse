from django.urls import path
app_name="webguest"
from Guest import views

urlpatterns=[

    path('Club/',views.ClubInsert,name="clubInsert"),
    path('Ajax/',views.Ajaxplace,name="ajaxplace"),
    path('User/',views.UserInsert,name="userInsert"),
    path('Login/',views.login,name="login"),
    path('Organization/',views.OrganizationInsert,name="organizationInsert"),

]