from django.db import models
from Admin.models import *

# Create your models here.

class tbl_newClub(models.Model):
    name=models.CharField(max_length=50)
    contact=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    place=models.ForeignKey(tbl_Place,on_delete=models.CASCADE)
    reg_no=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    logo=models.FileField(upload_to='logo')
    proof=models.FileField(upload_to='Proof')

class tbl_newUser(models.Model):
    name=models.CharField(max_length=50)
    contact=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    gender=models.CharField(max_length=50)
    addhar=models.CharField(max_length=50)
    place=models.ForeignKey(tbl_Place,on_delete=models.CASCADE)
    password=models.CharField(max_length=50)
    profile=models.FileField(upload_to='Profile')
    address=models.CharField(max_length=300)

class tbl_admin(models.Model):
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    pasword=models.CharField(max_length=50)

class tbl_organization(models.Model):
    name=models.CharField(max_length=50)
    contact=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    place=models.ForeignKey(tbl_Place,on_delete=models.CASCADE)
    reg_no=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    logo=models.FileField(upload_to='O_logo')
    proof=models.FileField(upload_to='O-Proof')