from django.shortcuts import render,redirect
from Guest.models import *
from Admin.models import *

# Create your views here.

#--------------------------Inserting values-----------------------------------
def ClubInsert(request):
    dis=tbl_District.objects.all()
    pl=tbl_Place.objects.all()
    if request.method=="POST":

        plaid=request.POST.get('sel_place')
        plac=tbl_Place.objects.get(id=plaid)

        tbl_newClub.objects.create(name=request.POST.get('txtCname'),contact=request.POST.get('phno'),email=request.POST.get('email'),reg_no=request.POST.get('Regno.'),password=request.POST.get('txtpass'),logo=request.FILES.get('Lpic'),proof=request.FILES.get('Ppic'),place=plac)
        return redirect("webguest:clubInsert")
    else:
        return render(request,"GUEST/Club.html",{'DIS':dis,'PLA':pl})
    

def UserInsert(request):
    dis=tbl_District.objects.all()
    pl=tbl_Place.objects.all()
    if request.method=="POST":

        plaid=request.POST.get('sel_place')
        plac=tbl_Place.objects.get(id=plaid)

        tbl_newUser.objects.create(name=request.POST.get('txtname'),contact=request.POST.get('txtPno'),email=request.POST.get('email'),gender=request.POST.get('gender'),addhar=request.POST.get('txtAdd'),place=plac,password=request.POST.get('txtpass'),profile=request.FILES.get('pic'),address=request.POST.get('address'))
        return redirect("webguest:userInsert")
    else:
        return render(request,"GUEST/User.html",{'DIS':dis,'PLA':pl})
    
def login(request):
    if request.method=="POST":
        Email=request.POST.get('txtUname')
        Password=request.POST.get('txtPass')
        clubcount=tbl_newClub.objects.filter(email=Email,password=Password).count()
        usercount=tbl_newUser.objects.filter(email=Email,password=Password).count()
        orgcount=tbl_organization.objects.filter(email=Email,password=Password).count()
        if clubcount>0:
            club=tbl_newClub.objects.get(email=Email,password=Password)
            request.session["cid"]=club.id
            return redirect("webclub:homeInsert")
        if usercount>0:
            user=tbl_newUser.objects.get(email=Email,password=Password)
            request.session["uid"]=user.id
            return redirect("webuser:homeInsert")
        if orgcount>0:
            org=tbl_organization.objects.get(email=Email,password=Password)
            request.session["oid"]=org.id
            return redirect("weborg:homeInsert")
    else:
        return render(request,"Guest/Login.html")
    
def OrganizationInsert(request):
    dis=tbl_District.objects.all()
    pl=tbl_Place.objects.all()
    if request.method=="POST":

        plaid=request.POST.get('sel_place')
        plac=tbl_Place.objects.get(id=plaid)

        tbl_organization.objects.create(name=request.POST.get('txtOname'),contact=request.POST.get('phno'),email=request.POST.get('email'),reg_no=request.POST.get('Regno.'),password=request.POST.get('txtpass'),logo=request.FILES.get('Lpic'),proof=request.FILES.get('Ppic'),place=plac)
        return redirect("webguest:organizationInsert")
    else:
        return render(request,"GUEST/Organization.html",{'DIS':dis,'PLA':pl})


    



#-------------------------Deleting values-----------------------------------




# ------------------------Editing values-----------------------------------








#-------------------------Ajax----------------------------

def Ajaxplace(request):
    dis=tbl_District.objects.get(id=request.GET.get('disd'))
    pl=tbl_Place.objects.filter(district=dis)
    return render(request,"Guest/Ajaxplace.html",{'plc':pl})