from django.urls import path
app_name="webclub"
from Club import views

urlpatterns = [

    path('HomePage/',views.HomePageInsert,name="homeInsert"),
    path('ChangePassword/',views.ChangePassInsert,name="changePInsert"),
    path('EditProfile/',views.EditProfileInsert,name="editPInsert"),
    path('MyProfile/',views.MyProfileInsert,name="MyPInsert"),
]