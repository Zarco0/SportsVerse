from django.shortcuts import render,redirect
from Club.models import *
from Guest.models import tbl_newClub

# Create your views here.
def HomePageInsert(request):
    if request.method=="POST":
        return redirect("webclub:homeInsert")
    else:
        return render(request,"Club/HomePage.html")
    
def ChangePassInsert(request):
    if request.method=="POST":
        clubcount=tbl_newClub.objects.filter(id=request.session["cid"],password=request.POST.get('Cpass')).count()
        if clubcount>0:
            club=tbl_newClub.objects.get(id=request.session["cid"],password=request.POST.get('Cpass'))
            if request.POST.get('Npass')==request.POST.get('ConPass'):
                club.password=request.POST.get('Npass')
                club.save()
                return redirect("webclub:homeInsert")
            else:
                return render(request,"Club/ChangePassword.html")
        else:
            return render(request,"Club/ChangePassword.html")
    else:
        return render(request,"Club/ChangePassword.html")
    
def EditProfileInsert(request):
    data=tbl_newClub.objects.get(id=request.session["cid"])
    if request.method=="POST":
        data.name=request.POST.get('txtname')
        data.contact=request.POST.get('txtcon')
        data.email=request.POST.get('txtemail')
        data.save()
        return redirect("webclub:MyPInsert")
    else:
        return render(request,"Club/EditProfile.html",{'data':data})
    
def MyProfileInsert(request):
    data=tbl_newClub.objects.get(id=request.session["cid"])
    return render(request,"Club/MyProfile.html",{'data':data})
    
